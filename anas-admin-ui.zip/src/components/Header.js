import React from 'react';

function Header() {
    return (
        <div className='container my-2'>
            <h4 className=''>Admin UI</h4>
        </div>
    );
}

export default Header;